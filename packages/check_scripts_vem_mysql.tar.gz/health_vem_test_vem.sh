#!/bin/bash
netstat -tupan |grep 3306
if [ $? -eq 0 ]
then
   printf "${SET_GREEN}MYSQL is listening on 3306\n${UNSET_COLOR}"
else
   printf "${SET_RED}It seems MYSQL is not working. 3306 is not found.\n${UNSET_COLOR}"
fi
