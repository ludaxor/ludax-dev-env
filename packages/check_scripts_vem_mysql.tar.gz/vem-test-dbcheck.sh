#!/bin/bash
SET_GREEN="\033[32m"
SET_RED="\033[31m"
UNSET_COLOR="\033[0m"

ps -ef |grep -i mysqld
if [ $? -eq 0 ]
then
   printf "${SET_GREEN}MYSQL is working\n${UNSET_COLOR}"
else
   printf "${SET_RED}MYSQL is not working\n${UNSET_COLOR}"
fi
