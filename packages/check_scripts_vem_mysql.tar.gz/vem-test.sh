#!/bin/bash
command -v mysql >/dev/null 2>&1
if [ $? -eq 0 ]
    then
	    echo -e "\e[00;32m#################################\e[00m"
        echo -e "\e[00;32m Mysql is installed\e[00m"
        echo -e "\e[00;32m#################################\e[00m"
	else
	    echo -e "\e[00;32m#################################\e[00m"
        echo -e "\e[00;32m Mysql is not installed\e[00m"
        echo -e "\e[00;32m#################################\e[00m"	
fi
