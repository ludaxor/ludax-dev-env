#!/bin/bash
netstat -tupan |grep 80
if [ $? -eq 0 ]
then
   printf "${SET_GREEN}Wordpress listens on 80 port.\n${UNSET_COLOR}"
else
   printf "${SET_RED}It seems Wordpress is not working. Port 80 is not found.\n${UNSET_COLOR}"
fi
