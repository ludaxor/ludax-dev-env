#!/bin/bash
WORDPRESS_URL="http://localhost:80"
curl -Is $WORDPRESS_URL
if [ $? -eq 0 ]
    then
	    echo -e "\e[00;32m#################################\e[00m"
        echo -e "\e[00;32m Wordpress URL is reachable.\e[00m"
        echo -e "\e[00;32m#################################\e[00m"
	else
	    echo -e "\e[00;32m#################################\e[00m"
        echo -e "\e[00;32m Wordpress URL is not reachable!\e[00m"
        echo -e "\e[00;32m#################################\e[00m"	
fi
