#!/bin/bash
#
# set_monitoring.sh
# based on haertbeat resource script opc_mon2
#
#      Description: Manages blocks in OVO configuration files
#  Original Author: Ulrich Gayer (ulrich.gayer@hp.com)
# Original Release: 19 Nov 2007

OPC_DIR=/var/opt/OV/conf/OpC

#usage() {
#cat <<-EOT
#        usage: $0 <cfg_file> <paragraph> {enable|disable}
#
#        <cfg_file>  : OpC monitoring configuration file basename (e.g. "ps_mon")
#        <paragraph> : identifier what lines to enable/disable in the config file
#
#        The lines to enable/disable must be enclosed by
#        a starting and an ending comment like this:
#        ### BEGIN <paragraph> ###
#        ### END <paragraph> ###
#
#        e.g.
#        ### BEGIN db-monitor ###
#        ...
#        ### END db-monitor ###
#        EOT
#}


# Check the arguments passed to this script
if [ $# -ne 3 ]; then
        usage
        exit 1
fi

if [ ! -d "$OPC_DIR" ] ; then
        echo "ERROR: Couldn't find directory '$OPC_DIR'" >&2
        exit 1
fi

MON_CFG="${1%.cfg}.cfg"
PARAGRAPH="$2"
BEGIN_ID="^##* BEGIN $PARAGRAPH #"
END_ID="^##* END $PARAGRAPH #"
operation=$3


if [ ! -f "$OPC_DIR/$MON_CFG" ] ; then
        echo "ERROR: Couldn't find configuration file '$MON_CFG'" >&2
        exit 1
fi

read mode uid gid < <(stat "$OPC_DIR/$MON_CFG" | tr '()/' ' ' | awk '/Uid:/ { print $2,$6,$9 }')

if [ `grep -c -e "$BEGIN_ID" -e "$END_ID" "$OPC_DIR/$MON_CFG"` -ne 2 ]; then
        echo "WARNING: Looks like '$MON_CFG' does not contain a proper paragraph '$PARAGRAPH'" >&2
        exit 2
fi


case "$operation" in
#
# Enabling: comment in the paragraph in the config file
#
enable | start )
        cd $OPC_DIR
        sed "/$BEGIN_ID/,/$END_ID/s/^#\([^#]\)/\1/" "$MON_CFG" > "/tmp/${MON_CFG}.tmp"
        chown ${uid}:${gid} "/tmp/${MON_CFG}.tmp"; chmod $mode "/tmp/${MON_CFG}.tmp"
        if mv "$MON_CFG" "${MON_CFG}.bkp" && mv "/tmp/${MON_CFG}.tmp" "$MON_CFG"; then
                echo "Paragraph '$PARAGRAPH' enabled in '$MON_CFG'"
        else
                echo "ERROR: couldn't enable paragraph '$PARAGRAPH' in '$MON_CFG'" >&2
                exit 3
        fi
# end of start)
;;

#
# Disabling: comment out the paragraph in the config file
#
disable | stop )
        cd $OPC_DIR
        sed "/$BEGIN_ID/,/$END_ID/s/^\([^#]\)/#\1/" "$MON_CFG" > "/tmp/${MON_CFG}.tmp"
        chown ${uid}:${gid} "/tmp/${MON_CFG}.tmp"; chmod $mode "/tmp/${MON_CFG}.tmp"
        if mv "$MON_CFG" "${MON_CFG}.bkp" && mv "/tmp/${MON_CFG}.tmp" "$MON_CFG"; then
                echo "Paragraph '$PARAGRAPH' disabled in '$MON_CFG'"
        else
                echo "ERROR: couldn't disable paragraph '$PARAGRAPH' in '$MON_CFG'" >&2
                exit 3
        fi
# end of stop)
;;


*)
    echo "This script should be run with a final argument of 'enable' or 'disable'"
    usage
    exit 1
;;

esac

exit 0
