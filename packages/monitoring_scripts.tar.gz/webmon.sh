#!/bin/bash
/root/scripts/set_monitoring.sh ps_mon "$2"-monitoring "$1"
/opt/WebMonG/bin/WebMonG.sh "$1" "$2"
