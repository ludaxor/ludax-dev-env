#!/bin/ksh
# restart.sh, generic restart script to be used with WebMonG
# WebMon(G)roovy, eis.team@hp.com
# (c) Copyright 2013 Hewlett-Packard Development Company, L.P.
# WebMonG_MLP_JAVAatHP-2.0.1.63.0.0.0
#
usage="restart.sh [-p pidFile] ... [-x script][-0 stopCmd][-1 startCmd][-t timeout][-s sleepTime] serviceName"
#
# This quite flexible restart script is typically called from WebMonG's
# bin/restart.sh wrapper script.
# The only mandatory argument is the serviceName: without any other arguments
# we use it to find the init.d script to be run with stop and start arguments.
# However, it's highly recommended to pass at least one pid file with the -p
# option. This enables the built-in killAll feature, killing recursively
# all processes and their children during stop. It also prevents restarts
# while the service is intentionally stopped, e.g. during maintenentance. We
# assume here that a clean shutdown remove the pid file, so we refuse to 
# restart if a configured pid file missing.
#

# We are only attempting to restart anything if all pid files are found!
# Without it we simply assume an intentionally stopped service.
# So valid pid files are mandatory for this script, either passed with the -p
# option or specfied in the config section below.
#
# Arguments:
#   serviceName: by default used to find default init.d scripts
#   pidFile:     pid file(s) containing the pid(s) of the running process(es)
#   script:      start/stop script without args,
#                default: /etc/init.d/<serviceName>, /sbin/init.d/<serviceName>
#   stopCmd:     stop command, default: <script> stop, overrides script
#   startCmd:    start command, default: <script> start, overrides script
#   timeout:     maximum time in seconds for stop command
#   sleepTime:   multi-purpose delay, e.g. used during stop and start
#
# Return values:
#   0:           OK
#   1:           FAILURE
#   2:           SKIPPED (script/command issues or pid files found)
#


# Platform specific stuff
initd="/etc/init.d"
case $(uname) in
	HP-UX)	function ps { export UNIX95=1; /usr/bin/ps "$@"; }
		initd="/sbin/init.d"
		;;
	SunOS)	function awk { /usr/xpg4/bin/awk "$@"; }
		function grep { /usr/xpg4/bin/grep "$@"; }
		;;
esac


# Helper to print info with time stamp
function info {
	echo "*** $(date '+%d.%m.%Y %H:%M:%S') $*" >&2
}


# Parse command line
cmdline="$*"
pidfiles=""; script=""; timeout="0"; sleeptime="10"; stopcmd=""; startcmd=""
while getopts "p:x:t:s:0:1:" opt; do
	case $opt in
		p)      pidfiles="$(echo $pidfiles $OPTARG)";;
		x)      script="$OPTARG";;
		t)      timeout="$OPTARG";;
		s)      sleeptime="$OPTARG";;
		0)      stopcmd="$OPTARG";;
		1)      startcmd="$OPTARG";;
	esac
done
shift $(($OPTIND -1))
if [ $# -ne 1 ]; then
	info "Usage: $usage"
	info "    ($0 $@)"
	exit 1
fi


# Fill/check variables
service="$1"
if [ -z "$startcmd" ]; then
	if [ -z "$stopcmd" ]; then
		script="${script:-$initd/$service}"
		if [ ! -f "$script" ]; then
			info "Script ($script) not found!"
			result=2
		else
			# ok, we try to use the script
			result=0
		fi
	else 
		info "Please define also startCmd!"
		result=2
	fi
else
	if [ -n "$stopcmd" ]; then
		# ok, we try to use stopCmd/startCmd
		script=""
		result=0
	else
		info "Please define also stopCmd!"
		result=2
	fi
fi


# Helper to find running procs including their child procs
function running {
	[ -z "$*" ] && return
	pslist=$(ps -e -o pid= -o ppid= | awk '{if ($1>10) print $1" ppid="$2";"}')
	inpids=$(ps -o pid= $(for pid in $*; do echo -p $pid; done) 2>&1)
	outpids=$inpids
	while [ -n "$inpids" ]; do
		pattern=$(for pid in $inpids; do echo "ppid=$pid;"; done)
		inpids=$(echo "$pslist" | grep -F "$pattern" | awk '{print $1}')
		outpids="$outpids $inpids"
	done
	echo $outpids
}


# let's go!
if [ "$result" = 0 ]; then
	info "Restart of service '$service' launched."
	info " ($0 $cmdline)"

	# if there are pid files specified, we want to see them ALL
	notfound=""; pids=""
	if [ -n "$pidfiles" ]; then
		for file in $pidfiles; do
			if [ -f "$file" ]; then
				# save pid file for later use
				cp -p "$file" "$file".bak$$
			else
				notfound="$(echo $notfound $file)"
			fi
		done
		pids="$(running $(cat $pidfiles 2>/dev/null))"
	fi

	if [ -z "$notfound" ]; then

		# with timeout > 0 we run the stop in background and wait
		if [ $timeout -gt 0 ]; then
			info "Stopping service '$service' (timeout=${timeout}s)..."
			if [ -n "$script" ]; then
				info " ($script stop)"
				chmod u+x "$script"
				"$script" stop  </dev/null &
			else
				info " ($stopcmd)"
				sh -c "$stopcmd"  </dev/null &
			fi
			bgpids=$(running $!)

			# Waiting for script termination
			count=0
			while [ $count -lt $timeout ]; do
				bgpids=$(running $bgpids)
				if [ -n "$bgpids" ]; then
					sleep 1
					count=$(($count+1))
				else
					info "Stop completed (${count}s)."
					break
				fi
			done

			# Kill the script if still running
			bgpids=$(running $bgpids)
			if [ -n "$bgpids" ]; then
				kill -9 $bgpids >/dev/null 2>&1
				info "Stop command killed after timeout."
			fi

		# without timeout run the stop in foreground
		else
			info "Stopping service '$service' (no timeout)..."
			if [ -n "$script" ]; then
				info " ($script stop)"
				chmod u+x "$script"
				"$script" stop </dev/null
			else
				info " ($stopcmd)"
				sh -c "$stopcmd"  </dev/null
			fi
			info "Stop completed."
		fi

		info "Waiting for ${sleeptime}s..."
		sleep $sleeptime

		# If we have pids... kill then all!
		pids=$(running $pids)
		if [ -n "$pids" ]; then
			info "Still running! (pid: $pids)"
			info "Sending SIGTERM and waiting for ${sleeptime}s..."
			kill -15 $pids >/dev/null 2>&1
			sleep $sleeptime
			# Well, now we use kill -9
			pids=$(running $pids)
			while [ -n "$pids" ]; do
				info "Still running! (pid: $pids)"
				info "Sending SIGKILL and waiting for ${sleeptime}s..."
				kill -9 $pids >/dev/null 2>&1
				sleep $sleeptime
				pids=$(running $pids)
			done
			info "Processes terminated."
		fi

		rm -f $pidfiles

		info "Starting service '$service'..."
		if [ -n "$script" ]; then
			info " ($script start)"
			chmod u+x "$script"
			"$script" start  </dev/null
			ret=$?
		else
			info " ($startcmd)"
			sh -c "$startcmd"  </dev/null
			ret=$?
		fi
		[ $ret != 0 ] && result=1
		info "Start completed (rc=$ret)."

		# for subsequent restart attempts, we need to ensure that at least empty pid files are present
		for file in $pidfiles; do
			if [ ! -f "$file" ]; then
				mv "$file".bak$$ "$file"
				true >"$file"
				echo "Created empty pid file ${file}."
			fi
			rm -f "$file".bak$$
		done

	else
		info "Pid file(s)s not found. Cowardly refusing to restart anything."
		info " ($notfound)"
		result=2
	fi
else
	info "Script/command issues. Cowardly refusing to restart anything."
fi


# exit with valid exit code
exit ${result}

#eof
