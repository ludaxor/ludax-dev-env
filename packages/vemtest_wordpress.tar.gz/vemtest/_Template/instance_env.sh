#!/bin/ksh
# instance_env.sh, instance specific environment definition
# WebMon(G)roovy, eis.team@hp.com
# (c) Copyright 2013 Hewlett-Packard Development Company, L.P.
# WebMonG_MLP_JAVAatHP-2.0.1.63.0.0.0
#
# To override built-in defaults and any global_env.sh settings.
#


### Uncomment this to disable OVO alarms.
#export WEBMON_ALERTLOG="/opt/WebMonG/log/webMonGAlert-doNotAlert.log"


### specify non-root runuser
#export RUNUSER=r2webmon
